import React from 'react';
import AdminCalender from './AdminCalender';

const EventPage = () => {
  return (
    <div>
      <AdminCalender />
    </div>
  );
};

export default EventPage;
