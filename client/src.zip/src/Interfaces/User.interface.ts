interface User {
	_id?: string;
	name: string;
	membershipId: string;
	phone: string;
	email: string;
	password: string;
}
export default User;
