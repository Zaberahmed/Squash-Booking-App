import Landing from '../Components/Landing/Landing.component';

function LandingPage() {
	return <Landing />;
}

export default LandingPage;
