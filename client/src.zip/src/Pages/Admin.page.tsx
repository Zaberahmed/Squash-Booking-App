import BottomBarAdmin from '../Components/BottomBar/BottomBar.Admin';
// import Upcoming from '../Components/Upcoming/Upcoming';
import UpcomingEvents from '../Components/Upcoming/UpcomingEvents';

const AdminPage = () => {
  return (
    <div>
      <UpcomingEvents />
      <BottomBarAdmin />
    </div>
  );
};

export default AdminPage;
